package br.com.empresaapp.view;

import br.com.empresaapp.model.Empresa;
import javax.swing.*;
import java.awt.*;

public class TelaEmpresa extends JFrame {

	private static final long serialVersionUID = 1L;

    private Empresa empresa = new Empresa();

    public TelaEmpresa() {
        setTitle("Sistema da Empresa");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(0, 1, 5, 5));

        JButton btnAddCliente = new JButton("Adicionar Cliente");
        JButton btnMostraCliente = new JButton("Exibir Clientes");
        JButton btnAddFuncionario = new JButton("Adicionar Funcionário");
        JButton btnMostraFuncionario = new JButton("Exibir Funcionários");
        JButton btnFolha = new JButton("Folha Salarial");
        JButton btnMedia = new JButton("Média Salarial");

        btnAddCliente.addActionListener(e -> {
            String nome = JOptionPane.showInputDialog(this, "Nome do cliente:");
            if (nome == null || nome.trim().isEmpty()) return;
            String email = JOptionPane.showInputDialog(this, "Email do cliente:");
            if (email == null || email.trim().isEmpty()) return;
            empresa.adicionarCliente(nome.trim(), email.trim());
            JOptionPane.showMessageDialog(this, "Cliente adicionado.");
        });

        btnMostraCliente.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, empresa.exibirClientes());
        });

        btnAddFuncionario.addActionListener(e -> {
            String nome = JOptionPane.showInputDialog(this, "Nome do funcionário:");
            if (nome == null || nome.trim().isEmpty()) return;
            String cargo = JOptionPane.showInputDialog(this, "Cargo:");
            if (cargo == null || cargo.trim().isEmpty()) return;
            String salarioStr = JOptionPane.showInputDialog(this, "Salário:");
            if (salarioStr == null || salarioStr.trim().isEmpty()) return;

            try {
                double salario = Double.parseDouble(salarioStr.replace(",", ".").trim());
                empresa.adicionarFuncionario(nome.trim(), cargo.trim(), salario);
                JOptionPane.showMessageDialog(this, "Funcionário adicionado.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Salário inválido. Informe um número.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnMostraFuncionario.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, empresa.exibirFuncionarios());
        });

        btnFolha.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Total da folha: R$ " + empresa.calcularFolhaSalarial());
        });

        btnMedia.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, empresa.exibirMediaSalarial());
        });

        painel.add(btnAddCliente);
        painel.add(btnMostraCliente);
        painel.add(btnAddFuncionario);
        painel.add(btnMostraFuncionario);
        painel.add(btnFolha);
        painel.add(btnMedia);

        add(painel);
        setVisible(true);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) { }

        SwingUtilities.invokeLater(() -> new TelaEmpresa());
    }
}
