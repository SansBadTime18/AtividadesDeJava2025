package br.com.empresaapp;

import br.com.empresaapp.view.TelaEmpresa;

public class Main {
    public static void main(String[] args) {
        new TelaEmpresa();
    }
}
