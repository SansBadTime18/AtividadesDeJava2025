package br.com.empresaapp.model;

public class Calculadora {

    public double somar(double a, double b) {
        return a + b;
    }

    public double multiplicar(double a, double b) {
        return a * b;
    }
}
