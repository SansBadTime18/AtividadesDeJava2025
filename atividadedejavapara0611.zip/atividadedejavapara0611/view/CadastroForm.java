package br.atividadedejavapara0611.view;


import br.atividadedejavapara0611.model.Cliente;
import javax.swing.*;
import java.awt.*;

public class CadastroForm extends JFrame {
	private static final long serialVersionUID = 1L;
    private JLabel lblNome, lblIdade, lblSexo, lblResumo;
    private JTextField txtNome;
    private JSpinner spnIdade;
    private JRadioButton rbMasculino, rbFeminino;
    private JButton btnEnviar;
    private ButtonGroup grupoSexo;

    public CadastroForm() {
        setTitle("Formulário de Cadastro");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 5, 5));
        setSize(350, 250);
        setLocationRelativeTo(null);

        lblNome = new JLabel("Nome:");
        txtNome = new JTextField();

        lblIdade = new JLabel("Idade:");
        spnIdade = new JSpinner(new SpinnerNumberModel(18, 0, 120, 1));

        lblSexo = new JLabel("Sexo:");
        rbMasculino = new JRadioButton("Masculino");
        rbFeminino = new JRadioButton("Feminino");
        grupoSexo = new ButtonGroup();
        grupoSexo.add(rbMasculino);
        grupoSexo.add(rbFeminino);

        btnEnviar = new JButton("Enviar");
        lblResumo = new JLabel();

        add(lblNome);
        add(txtNome);

        add(lblIdade);
        add(spnIdade);

        add(lblSexo);
        JPanel painelSexo = new JPanel();
        painelSexo.add(rbMasculino);
        painelSexo.add(rbFeminino);
        add(painelSexo);

        add(btnEnviar);
        add(lblResumo);

        btnEnviar.addActionListener(e -> enviarDados());

        setVisible(true);
    }

    private void enviarDados() {
        String nome = txtNome.getText().trim();
        int idade = (Integer) spnIdade.getValue();
        String sexo = rbMasculino.isSelected() ? "Masculino"
                     : rbFeminino.isSelected() ? "Feminino" : "";

        if (nome.isEmpty() || sexo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!", 
                                          "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente cliente = new Cliente(nome, idade, sexo);

        lblResumo.setText(cliente.toString());
    }
}
