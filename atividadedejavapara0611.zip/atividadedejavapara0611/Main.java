package br.atividadedejavapara0611;

import br.atividadedejavapara0611.view.CadastroForm;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CadastroForm());
    }
}
