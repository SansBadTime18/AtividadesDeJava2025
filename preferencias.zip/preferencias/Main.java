package br.com.preferencias;

import javax.swing.SwingUtilities;
import br.com.preferencias.view.PreferenciasUsuario;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PreferenciasUsuario());
    }
}
