package br.com.preferencias.view;

import br.com.preferencias.model.Usuario;
import javax.swing.*;
import java.awt.*;

public class PreferenciasUsuario extends JFrame {
	private static final long serialVersionUID = 1L;
    private JLabel lblTema, lblNotif, lblVolume;
    private JComboBox<String> cbTema;
    private JCheckBox chkNotificacoes;
    private JSlider sldVolume;
    private JButton btnSalvar;
    private JTextArea txtResultado;

    private Usuario usuario;

    public PreferenciasUsuario() {
        setTitle("Configurações de Preferências do Usuário");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel painel = new JPanel(new GridLayout(4, 2, 10, 10));

        lblTema = new JLabel("Tema:");
        cbTema = new JComboBox<>(new String[]{"Claro", "Escuro"});

        lblNotif = new JLabel("Notificações:");
        chkNotificacoes = new JCheckBox("Habilitar");

        lblVolume = new JLabel("Volume:");
        sldVolume = new JSlider(0, 100, 50);
        sldVolume.setMajorTickSpacing(25);
        sldVolume.setPaintTicks(true);
        sldVolume.setPaintLabels(true);

        btnSalvar = new JButton("Salvar");
        txtResultado = new JTextArea(4, 20);
        txtResultado.setEditable(false);
        txtResultado.setLineWrap(true);
        txtResultado.setWrapStyleWord(true);

        painel.add(lblTema);
        painel.add(cbTema);
        painel.add(lblNotif);
        painel.add(chkNotificacoes);
        painel.add(lblVolume);
        painel.add(sldVolume);
        painel.add(new JLabel());
        painel.add(btnSalvar);

        add(painel, BorderLayout.CENTER);
        add(new JScrollPane(txtResultado), BorderLayout.SOUTH);

        btnSalvar.addActionListener(e -> salvarPreferencias());
        cbTema.addActionListener(e -> atualizarCorTema());

        atualizarCorTema();

        setVisible(true);
    }

    private void salvarPreferencias() {
        String tema = (String) cbTema.getSelectedItem();
        boolean notificacoes = chkNotificacoes.isSelected();
        int volume = sldVolume.getValue();

        usuario = new Usuario(tema, notificacoes, volume);
        txtResultado.setText("Preferências salvas:\n" + usuario.toString());
    }

    private void atualizarCorTema() {
        String temaSelecionado = (String) cbTema.getSelectedItem();
        if ("Escuro".equals(temaSelecionado)) {
            getContentPane().setBackground(Color.DARK_GRAY);
            txtResultado.setBackground(Color.LIGHT_GRAY);
            txtResultado.setForeground(Color.BLACK);
        } else {
            getContentPane().setBackground(Color.WHITE);
            txtResultado.setBackground(Color.WHITE);
            txtResultado.setForeground(Color.BLACK);
        }
    }
}
