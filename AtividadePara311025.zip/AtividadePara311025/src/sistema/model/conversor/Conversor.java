package sistema.model.conversor;

public class Conversor {
    public double converter(double celsius) {
        return (celsius * 9/5) + 32; // Celsius → Fahrenheit
    }

    public double converter(double km, boolean paraMilhas) {
        return paraMilhas ? km * 0.621371 : km / 0.621371;
    }

    public String converter(String texto) {
        return texto.toUpperCase();
    }
}
