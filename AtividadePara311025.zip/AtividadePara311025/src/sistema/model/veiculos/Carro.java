package sistema.model.veiculos;

public class Carro extends Veiculo {
    @Override
    public void mover() {
        System.out.println("O carro está dirigindo");
    }
}
