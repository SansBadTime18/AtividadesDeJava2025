package sistema.model.veiculos;

public class Veiculo {
    public void mover() {
        System.out.println("O veículo está se movendo");
    }
}
