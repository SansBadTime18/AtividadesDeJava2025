package sistema.model.pagamentos;

public class Pagamento {
    public void processarPagamento() {
        System.out.println("Processando pagamento genérico");
    }
}
