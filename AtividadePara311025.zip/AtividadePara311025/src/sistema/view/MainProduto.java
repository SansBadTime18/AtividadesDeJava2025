package sistema.view;

import sistema.model.produtos.Produto;

public class MainProduto {
    public static void main(String[] args) {
        Produto p1 = new Produto("Caneta");
        Produto p2 = new Produto("Lápis", 1.50);
        Produto p3 = new Produto("Caderno", 10.00, 5);

        p1.exibirInfo();
        p2.exibirInfo();
        p3.exibirInfo();
    }
}
