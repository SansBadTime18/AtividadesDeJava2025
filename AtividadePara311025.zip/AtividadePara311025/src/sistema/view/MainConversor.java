package sistema.view;

import sistema.model.conversor.Conversor;

public class MainConversor {
    public static void main(String[] args) {
        Conversor conv = new Conversor();

        System.out.println(conv.converter(25.0));          // Celsius → Fahrenheit
        System.out.println(conv.converter(10.0, true));    // Km → Milhas
        System.out.println(conv.converter("java"));        // Texto → Maiúsculas
    }
}
