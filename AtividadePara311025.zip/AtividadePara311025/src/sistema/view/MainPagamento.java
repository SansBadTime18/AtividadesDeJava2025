package sistema.view;

import sistema.model.pagamentos.*;

public class MainPagamento {
    public static void main(String[] args) {
        Pagamento p1 = new PagamentoCartao();
        Pagamento p2 = new PagamentoBoleto();
        Pagamento p3 = new Pagamento();

        p1.processarPagamento();
        p2.processarPagamento();
        p3.processarPagamento();
    }
}
